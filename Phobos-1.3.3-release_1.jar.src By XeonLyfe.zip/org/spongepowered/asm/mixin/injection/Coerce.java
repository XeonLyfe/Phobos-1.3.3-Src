package org.spongepowered.asm.mixin.injection;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ElementType.PARAMETER})
public @interface Coerce {}


/* Location:              C:\Users\XeonLyfe\Desktop\Phobos-1.3.3-release_1.jar!\org\spongepowered\asm\mixin\injection\Coerce.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */