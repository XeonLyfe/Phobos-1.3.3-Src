/*   */ package me.earth.phobos.event.events;
/*   */ 
/*   */ import me.earth.phobos.event.EventStage;
/*   */ 
/*   */ public class UpdateWalkingPlayerEvent
/*   */   extends EventStage {
/*   */   public UpdateWalkingPlayerEvent(int stage) {
/* 8 */     super(stage);
/*   */   }
/*   */ }


/* Location:              C:\Users\XeonLyfe\Desktop\Phobos-1.3.3-release_1.jar!\me\earth\phobos\event\events\UpdateWalkingPlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */